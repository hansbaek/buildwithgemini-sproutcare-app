# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ..schema.constants import CATALOG_SCHEMA_KEY, VERSION_0_8, VERSION_0_9, VERSION_0_9_1

BASIC_CATALOG_NAME = "basic"

# Maps version to the relative path of the basic catalog schema in the source repo
BASIC_CATALOG_PATHS = {
    VERSION_0_8: {
        CATALOG_SCHEMA_KEY: "specification/v0_8/json/standard_catalog_definition.json"
    },
    VERSION_0_9: {CATALOG_SCHEMA_KEY: "specification/v0_9/catalogs/basic/catalog.json"},
    VERSION_0_9_1: {
        CATALOG_SCHEMA_KEY: "specification/v0_9_1/catalogs/basic/catalog.json"
    },
}

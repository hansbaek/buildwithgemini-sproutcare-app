# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import datetime
import json
import math
import re
from typing import Any
from urllib.parse import urlparse

from ...resolution.data_context import DataContext
from ...common.events import AbortSignal
from ...exceptions import A2uiExpressionError
from ...catalog import (
    FunctionImplementation,
    create_function_implementation,
    system_functions_for,
)
from .function_apis import (
    RequiredApi,
    RegexApi,
    LengthApi,
    NumericApi,
    EmailApi,
    FormatStringApi,
    FormatNumberApi,
    FormatCurrencyApi,
    FormatDateApi,
    PluralizeApi,
    OpenUrlApi,
    AndApi,
    OrApi,
    NotApi,
)
from ...expressions.expression_parser import ExpressionParser
from ...schema.v1_0.constants import PROTOCOL_VERSION
from ..locale_formatting import apply_currency_spacing, get_locale
from babel.numbers import format_decimal, format_currency, get_currency_symbol
import re as _re


def _to_float(val: Any) -> float:
    try:
        return float(val)
    except (ValueError, TypeError):
        raise ValueError(f"Cannot convert to number: {val}")


def _to_bool(val: Any) -> bool:
    return bool(val)


def _to_str(val: Any) -> str:
    if val is None:
        return ""
    if isinstance(val, (dict, list)):
        return json.dumps(val, separators=(",", ":"))
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, float):
        if math.isinf(val):
            return "-Infinity" if val < 0 else "Infinity"
        if math.isnan(val):
            return "NaN"
    return str(val)


# Validation (v1.0 returns validationResult: {"valid": bool})
def _required_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> dict[str, Any]:
    valid = _to_bool(
        args.get("value") is not None
        and args.get("value") != ""
        and args.get("value") != []
    )
    return {"valid": valid}


RequiredImplementation = create_function_implementation(RequiredApi, _required_execute)


def _regex_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> dict[str, Any]:
    pattern = _to_str(args.get("pattern", ""))
    val = _to_str(args.get("value", ""))
    try:
        valid = bool(re.search(pattern, val))
    except re.error as e:
        raise A2uiExpressionError(f"Invalid regex pattern '{pattern}': {e}") from e
    return {"valid": valid}


RegexImplementation = create_function_implementation(RegexApi, _regex_execute)


def _length_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> dict[str, Any]:
    val = args.get("value")
    if isinstance(val, list):
        l = len(val)
    elif val is None:
        l = 0
    else:
        l = len(_to_str(val))
    valid = (args.get("min") is None or l >= int(args["min"])) and (
        args.get("max") is None or l <= int(args["max"])
    )
    return {"valid": valid}


LengthImplementation = create_function_implementation(LengthApi, _length_execute)


def _numeric_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> dict[str, Any]:
    try:
        val = _to_float(args["value"])
    except (ValueError, TypeError):
        return {"valid": False}
    min_val = args.get("min")
    if min_val is not None:
        try:
            if val < _to_float(min_val):
                return {"valid": False}
        except (ValueError, TypeError):
            return {"valid": False}
    max_val = args.get("max")
    if max_val is not None:
        try:
            if val > _to_float(max_val):
                return {"valid": False}
        except (ValueError, TypeError):
            return {"valid": False}
    return {"valid": True}


NumericImplementation = create_function_implementation(NumericApi, _numeric_execute)


def _email_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> dict[str, Any]:
    valid = bool(
        re.match(
            r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
            _to_str(args.get("value", "")),
        )
    )
    if valid:
        return {"valid": True}
    return {
        "valid": False,
        "code": "INVALID_EMAIL",
        "message": "Please enter a valid email address (e.g. user@example.com).",
        "severity": "error",
    }


EmailImplementation = create_function_implementation(EmailApi, _email_execute)


def _adapt_ast_part_for_v10(part: Any) -> Any:
    if not isinstance(part, dict):
        return part
    if (
        "path" in part
        and isinstance(part["path"], str)
        and "componentId" not in part
        and "@path" not in part
    ):
        return {"@path": part["path"]}
    if "call" in part and isinstance(part["call"], str) and "@call" not in part:
        args = {}
        raw_args = part.get("args")
        if isinstance(raw_args, dict):
            for k, v in raw_args.items():
                args[k] = _adapt_ast_part_for_v10(v)
        res = {"@call": part["call"], "args": args}
        if "returnType" in part:
            res["returnType"] = part["returnType"]
        return res
    return part


# Formatting
def _format_string(
    args: dict[str, Any],
    context: DataContext,
    abort_signal: AbortSignal | None = None,
) -> str:
    template = _to_str(args.get("value", ""))
    if not template:
        return ""

    parser = ExpressionParser()
    parts = parser.parse(template)

    if not parts:
        return ""

    resolved_parts = []
    for part in parts:
        if context and hasattr(context, "resolve_dynamic_value"):
            dyn_part = (
                _adapt_ast_part_for_v10(part)
                if getattr(context, "is_v10", False)
                else part
            )
            resolved = context.resolve_dynamic_value(dyn_part)
        else:
            resolved = part
        resolved_parts.append(_to_str(resolved))

    return "".join(resolved_parts)


FormatStringImplementation = create_function_implementation(
    FormatStringApi, _format_string
)


def _format_numeric_locale(
    val: float,
    decimals: int | None,
    grouping: bool,
    locale: str | None,
) -> str:
    loc = get_locale(locale)
    if decimals is not None:
        pat = str(loc.decimal_formats[None].pattern)
        if decimals == 0:
            pat = _re.sub(r"0\.[0#]+", "0", pat)
        else:
            pat = _re.sub(r"0\.[0#]+", "0." + "0" * decimals, pat)
        return format_decimal(val, format=pat, locale=loc, group_separator=grouping)
    return format_decimal(val, locale=loc, group_separator=grouping)


def create_format_number_implementation(
    locale: str | None = None,
) -> FunctionImplementation:
    def _format_number(
        args: dict[str, Any],
        context: DataContext,
        abort_signal: AbortSignal | None = None,
    ) -> str:
        val = _to_float(args.get("value", 0))
        decimals = int(args["decimals"]) if args.get("decimals") is not None else None
        grouping = True if args.get("grouping") is None else bool(args["grouping"])
        return _format_numeric_locale(val, decimals, grouping, locale)

    return create_function_implementation(FormatNumberApi, _format_number)


FormatNumberImplementation = create_format_number_implementation(None)


def create_format_currency_implementation(
    locale: str | None = None,
) -> FunctionImplementation:
    def _format_currency(
        args: dict[str, Any],
        context: DataContext,
        abort_signal: AbortSignal | None = None,
    ) -> str:
        val = _to_float(args.get("value", 0))
        currency = str(args.get("currency", "USD")).upper()
        decimals = int(args["decimals"]) if args.get("decimals") is not None else 2
        grouping = True if args.get("grouping") is None else bool(args["grouping"])

        loc = get_locale(locale)
        pat = loc.currency_formats["standard"].pattern
        if decimals == 0:
            pat = _re.sub(r"0\.[0#]+", "0", pat)
        else:
            pat = _re.sub(r"0\.[0#]+", "0." + "0" * decimals, pat)
        # Babel resolves the pattern and symbol from CLDR but skips CLDR's
        # `currencySpacing`, which `Intl` applies. Without this the two engines
        # disagree for every alphabetic symbol, `CHF` and `SEK` among them.
        pat = apply_currency_spacing(pat, get_currency_symbol(currency, locale=loc))
        return format_currency(
            val,
            currency,
            format=pat,
            locale=loc,
            group_separator=grouping,
            currency_digits=False,
        )

    return create_function_implementation(FormatCurrencyApi, _format_currency)


FormatCurrencyImplementation = create_format_currency_implementation(None)

_DATE_TOKENS = re.compile(r"yyyy|yy|MMMM|MMM|MM|M|EEEE|E|dd|d|HH|H|hh|h|mm|ss|a|%")


def create_format_date_implementation(
    locale: str | None = None,
) -> FunctionImplementation:
    def _format_date(
        args: dict[str, Any],
        context: DataContext,
        abort_signal: AbortSignal | None = None,
    ) -> str:
        val = args.get("value")
        fmt = str(args.get("format", "yyyy-MM-dd"))
        if not val:
            return ""
        try:
            dt = datetime.datetime.fromisoformat(str(val).replace("Z", "+00:00"))
            if fmt == "ISO":
                # Mirror JavaScript's Date.prototype.toISOString(): always the
                # UTC instant, always exactly three fractional digits. A naive
                # timestamp is read as UTC so the result never depends on the
                # host time zone.
                utc = (
                    dt.replace(tzinfo=datetime.timezone.utc)
                    if dt.tzinfo is None
                    else dt.astimezone(datetime.timezone.utc)
                )
                millis = utc.microsecond // 1000
                return f"{utc.strftime('%Y-%m-%dT%H:%M:%S')}.{millis:03d}Z"

            loc = get_locale(locale)

            def _sub(m: re.Match[str]) -> str:
                tok = m.group(0)
                if tok == "yyyy":
                    return str(dt.year)
                if tok == "yy":
                    return str(dt.year)[-2:]
                if tok == "MMMM":
                    return str(loc.months["format"]["wide"][dt.month])
                if tok == "MMM":
                    return str(loc.months["format"]["abbreviated"][dt.month])
                if tok == "MM":
                    return f"{dt.month:02d}"
                if tok == "M":
                    return str(dt.month)
                if tok == "EEEE":
                    return str(loc.days["format"]["wide"][dt.weekday()])
                if tok == "E":
                    return str(loc.days["format"]["abbreviated"][dt.weekday()])
                if tok == "dd":
                    return f"{dt.day:02d}"
                if tok == "d":
                    return str(dt.day)
                if tok == "HH":
                    return f"{dt.hour:02d}"
                if tok == "H":
                    return str(dt.hour)
                if tok == "hh":
                    hr = dt.hour % 12
                    return f"{(hr or 12):02d}"
                if tok == "h":
                    hr = dt.hour % 12
                    return str(hr or 12)
                if tok == "mm":
                    return f"{dt.minute:02d}"
                if tok == "ss":
                    return f"{dt.second:02d}"
                if tok == "a":
                    return "AM" if dt.hour < 12 else "PM"
                return tok

            return _DATE_TOKENS.sub(_sub, fmt)
        except Exception:
            return ""

    return create_function_implementation(FormatDateApi, _format_date)


FormatDateImplementation = create_format_date_implementation(None)


def create_pluralize_implementation(
    locale: str | None = None,
) -> FunctionImplementation:
    def _pluralize(
        args: dict[str, Any],
        context: DataContext,
        abort_signal: AbortSignal | None = None,
    ) -> str:
        val = _to_float(args.get("value", 0))
        loc = get_locale(locale)

        category = "other"
        if val == 0 and "zero" in args:
            category = "zero"
        elif val == 1 and "one" in args:
            category = "one"
        elif val == 2 and "two" in args:
            category = "two"
        else:
            category = loc.plural_form(val)

        # Fall back on absence, not falsiness: a caller that supplies an empty
        # string for a category means "render nothing" for that category, and
        # the category was already selected above by key presence.
        res = args.get(category)
        if res is None:
            res = args.get("other")
        if res is None:
            res = ""
        return str(res)

    return create_function_implementation(PluralizeApi, _pluralize)


PluralizeImplementation = create_pluralize_implementation(None)


_ALLOWED_URL_SCHEMES = ("http:", "https:", "mailto:", "tel:")


# Actions
def _open_url_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> None:
    url = args.get("url")
    if not isinstance(url, str) or not url.strip():
        return None

    parsed = urlparse(url)
    scheme = f"{parsed.scheme.lower()}:"
    if scheme not in _ALLOWED_URL_SCHEMES:
        raise A2uiExpressionError(f"Unsupported URL scheme: {parsed.scheme}")
    return None


OpenUrlImplementation = create_function_implementation(OpenUrlApi, _open_url_execute)


# Logical
#
# The v1.0 validators return a ValidationResult rather than a boolean, so a
# nested ``and(required(...), or(...))`` receives dicts. A dict with a boolean
# ``valid`` member is truthy by its validity, not by being a non-empty dict.
def _is_truthy_or_valid(val: Any) -> bool:
    if isinstance(val, dict):
        valid = val.get("valid")
        if isinstance(valid, bool):
            return valid
    return _to_bool(val)


def _and_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> bool:
    values = args.get("values")
    if not isinstance(values, list) or len(values) < 2:
        raise A2uiExpressionError("AndFunction requires at least 2 values")
    return all(_is_truthy_or_valid(v) for v in values)


AndImplementation = create_function_implementation(AndApi, _and_execute)


def _or_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> bool:
    values = args.get("values")
    if not isinstance(values, list) or len(values) < 2:
        raise A2uiExpressionError("OrFunction requires at least 2 values")
    return any(_is_truthy_or_valid(v) for v in values)


OrImplementation = create_function_implementation(OrApi, _or_execute)


def _not_execute(
    args: dict[str, Any],
    context: Any = None,
    abort_signal: Any | None = None,
) -> bool:
    return not _is_truthy_or_valid(args.get("value"))


NotImplementation = create_function_implementation(NotApi, _not_execute)


def create_basic_catalog_functions(
    locale: str | None = None,
) -> list[FunctionImplementation]:
    """Builds the function set for a v1.0 basic catalog.

    The set matches the functions declared in
    ``specification/v1_0/catalogs/basic/catalog.json``, plus the ``@index``
    system function, which the ``@`` namespace makes available to every
    catalog.

    Args:
      locale: BCP 47 language tag applied to the formatting functions. Falls
        back to the library default when omitted.

    Returns:
      The function implementations, ready to register on a catalog.
    """
    return [
        RequiredImplementation,
        RegexImplementation,
        LengthImplementation,
        NumericImplementation,
        EmailImplementation,
        *system_functions_for(PROTOCOL_VERSION).values(),
        FormatStringImplementation,
        create_format_number_implementation(locale),
        create_format_currency_implementation(locale),
        create_format_date_implementation(locale),
        create_pluralize_implementation(locale),
        OpenUrlImplementation,
        AndImplementation,
        OrImplementation,
        NotImplementation,
    ]


BASIC_FUNCTION_IMPLEMENTATIONS = create_basic_catalog_functions(None)

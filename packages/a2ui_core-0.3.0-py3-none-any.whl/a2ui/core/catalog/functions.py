# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import inspect
from typing import (
    Any,
    Callable,
    Generic,
    Literal,
    Type,
    cast,
)
from typing_extensions import TypeVar

AllowedCallers = Literal["rendererOnly", "agentOnly", "rendererOrAgent"]
FunctionReturnType = Literal[
    "string",
    "number",
    "boolean",
    "array",
    "object",
    "validationResult",
    "any",
    "void",
]

# InferA2uiReturnType mapping in Python: maps FunctionReturnType to concrete Python return types
InferA2uiReturnType = str | int | float | bool | list[Any] | dict[str, Any] | None | Any

TReturn = TypeVar("TReturn", bound=InferA2uiReturnType, default=Any)


class FunctionApi:
    """The API definition of a catalog function (schema-only)."""

    def __init__(
        self,
        name: str,
        return_type: FunctionReturnType | None = "any",
        schema: Any = None,
        allowed_callers: AllowedCallers | None = "rendererOnly",
        requires_user_activation: bool | None = False,
        description: str | None = None,
    ):
        """Initializes the function API.

        Args:
            name: The function's name, which calls use as `call`.
            return_type: The type of the function's result.
            schema: The schema of the function's `args`, as a Pydantic model
                class or a JSON schema.
            allowed_callers: Who may call the function.
            requires_user_activation: Whether a call needs a user gesture.
            description: What the function does, published in the catalog
                schema.
        """
        self.name = name
        self.return_type = return_type or "any"
        self.schema = schema
        self.allowed_callers = allowed_callers or "rendererOnly"
        self.requires_user_activation = bool(requires_user_activation)
        self.description = (
            description
            if description is not None
            else getattr(self, "description", None)
        )


class FunctionImplementation(FunctionApi, Generic[TReturn]):
    """Extends FunctionApi with executable Python logic and runtime validation."""

    def __init__(
        self,
        name: str,
        return_type: FunctionReturnType | None = "any",
        schema: Any = None,
        execute: Callable[[dict[str, Any], Any, Any | None], TReturn] | None = None,
        allowed_callers: AllowedCallers | None = "rendererOnly",
        requires_user_activation: bool | None = False,
        description: str | None = None,
    ):
        super().__init__(
            name=name,
            return_type=return_type,
            schema=schema,
            allowed_callers=allowed_callers,
            requires_user_activation=requires_user_activation,
            description=description,
        )
        self.execute_func = execute

    def execute(
        self,
        args: dict[str, Any],
        context: Any = None,
        abort_signal: Any | None = None,
    ) -> TReturn:
        """Runs the function with already-validated, already-resolved arguments.

        ``execute`` does not validate ``args``. The argument schema describes
        the arguments as written in a payload (a ``DynamicBoolean`` admits a
        ``{"@call": ...}``), so it applies before bindings and nested calls are
        resolved, not to the resolved values this method receives. The caller
        validates the written arguments, with
        ``PayloadValidator.validate_function`` or the schema model directly,
        resolves them, and then calls ``execute``. ``DataContext`` does this
        for every call it evaluates.

        Args:
            args: The named arguments, resolved to plain values.
            context: The data context the call is evaluated in.
            abort_signal: Cancels a long-running call.
        """
        if self.execute_func is None:
            raise ValueError(f"Function {self.name} has no executable logic.")
        exec_fn = cast(Callable[..., TReturn], self.execute_func)
        try:
            sig = inspect.signature(exec_fn)
            param_count = len(sig.parameters)
        except (ValueError, TypeError):
            param_count = 3

        if param_count >= 3:
            return exec_fn(args, context, abort_signal)
        elif param_count == 2:
            return exec_fn(args, context)
        else:
            return exec_fn(args)


def create_function_implementation(
    api: FunctionApi | Type[FunctionApi],
    execute: Callable[[dict[str, Any], Any, Any | None], TReturn],
) -> FunctionImplementation[TReturn]:
    """Creates a FunctionImplementation from a FunctionApi specification and an executable closure."""
    return FunctionImplementation[TReturn](
        name=getattr(api, "name", ""),
        return_type=getattr(api, "return_type", "any"),
        schema=getattr(api, "schema", None),
        execute=execute,
        allowed_callers=getattr(api, "allowed_callers", "rendererOnly"),
        requires_user_activation=getattr(api, "requires_user_activation", False),
        description=getattr(api, "description", None),
    )


"""
A function that invokes a catalog function by name and returns its result synchronously.

Parameters:
    name: The name of the function to invoke.
    args: The arguments to pass to the function.
    context: The data context in which the function is being executed.
    abort_signal: An optional AbortSignal for asynchronous or long-running operations.

Returns:
    The result of the function call (e.g. literal, list, dict, or None).
"""
FunctionInvoker = Callable[[str, dict[str, Any], Any, Any | None], Any]

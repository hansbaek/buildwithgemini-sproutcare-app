# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math
import re
from typing import Any, Final
import regex

from a2ui.core.exceptions import A2uiExpressionError

MAX_EXPRESSION_TEMPLATE_LENGTH: Final[int] = 10_000
MAX_EXPRESSION_PARTS: Final[int] = 1_000

# An optional sign, a mantissa (`5`, `5.`, `5.25`, or `.5`), and an optional
# exponent (`e` or `E`, an optional sign, digits). Uses `[0-9]` rather than `\d`
# because Python's `\d` matches Unicode digits from every script.
# Every engine checks the same pattern: `NUMBER_LITERAL` in TypeScript,
# `_numberLiteral` in Dart, and `ExpressionParser.numberLiteralPattern` in
# Swift.
_NUMBER_LITERAL: Final[re.Pattern[str]] = re.compile(
    r"^[+-]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$"
)

# Compiled pattern matching exactly one XID_Continue character
XID_CONTINUE_PATTERN = regex.compile(r"^\p{XID_Continue}$")


def _is_id_continue(char: str) -> bool:
    """Returns True if character belongs to Unicode UAX #31 XID_Continue."""
    if not char or len(char) != 1:
        return False
    return bool(XID_CONTINUE_PATTERN.match(char))


class Scanner:

    def __init__(self, input_str: str) -> None:
        self.input = input_str
        self.pos = 0

    def is_at_end(self) -> bool:
        return self.pos >= len(self.input)

    def peek(self, offset: int = 0) -> str:
        if self.pos + offset >= len(self.input):
            return "\0"
        return self.input[self.pos + offset]

    def advance(self, count: int = 1) -> str:
        chars = self.input[self.pos : self.pos + count]
        self.pos += count
        return chars

    def match(self, expected: str) -> bool:
        if self.peek() == expected:
            self.advance()
            return True
        return False

    def matches(self, expected: str) -> bool:
        return self.input.startswith(expected, self.pos)

    def matches_string(self, expected: str) -> bool:
        return self.peek() == expected

    def matches_keyword(self, keyword: str) -> bool:
        if self.input.startswith(keyword, self.pos):
            next_char = self.peek(len(keyword))
            if not _is_id_continue(next_char):
                self.advance(len(keyword))
                return True
        return False

    def skip_whitespace(self) -> None:
        while not self.is_at_end() and self.peek().isspace():
            self.advance()


class ExpressionParser:
    #: The maximum allowed recursion depth for nested expressions, which bounds
    #: the work a payload can demand of the parser and keeps it off the stack
    #: limit. Every engine uses the same number: ``ExpressionParser.MAX_DEPTH``
    #: in TypeScript and ``ExpressionParser.maxDepth`` in Swift. They must
    #: agree, or an expression one engine accepts the other rejects.
    MAX_DEPTH = 100

    def parse(self, input_str: str, depth: int = 0) -> list[Any]:
        if depth > self.MAX_DEPTH:
            raise A2uiExpressionError("Max recursion depth reached in parse")
        if input_str and len(input_str) > MAX_EXPRESSION_TEMPLATE_LENGTH:
            raise A2uiExpressionError(
                f"Expression template length ({len(input_str)}) exceeds maximum"
                f" limit ({MAX_EXPRESSION_TEMPLATE_LENGTH})"
            )
        if not input_str or "${" not in input_str:
            return [input_str] if input_str else []

        parts: list[Any] = []
        scanner = Scanner(input_str)

        while not scanner.is_at_end():
            if len(parts) >= MAX_EXPRESSION_PARTS:
                raise A2uiExpressionError(
                    "Expression parts count exceeds maximum limit"
                    f" ({MAX_EXPRESSION_PARTS})"
                )
            if scanner.matches("${"):
                scanner.advance(2)
                content = self.extract_interpolation_content(scanner)
                parsed = self.parse_expression(content, depth + 1)
                if parsed is not None and parsed != "":
                    parts.append(parsed)
            elif (
                scanner.peek() == "\\"
                and scanner.peek(1) == "$"
                and scanner.peek(2) == "{"
            ):
                scanner.advance()
                parts.append("${")
                scanner.advance(2)
            else:
                start = scanner.pos
                while not scanner.is_at_end():
                    if scanner.matches("${"):
                        break
                    if (
                        scanner.peek() == "\\"
                        and scanner.peek(1) == "$"
                        and scanner.peek(2) == "{"
                    ):
                        break
                    scanner.advance()
                text_content = scanner.input[start : scanner.pos]
                if text_content:
                    parts.append(text_content)

        return [p for p in parts if p is not None and p != ""]

    def extract_interpolation_content(self, scanner: Scanner) -> str:
        start = scanner.pos
        brace_balance = 1

        while not scanner.is_at_end() and brace_balance > 0:
            char = scanner.advance()
            if char == "{":
                brace_balance += 1
            elif char == "}":
                brace_balance -= 1
            elif char == "'" or char == '"':
                quote = char
                while not scanner.is_at_end():
                    c = scanner.advance()
                    if c == "\\":
                        scanner.advance()
                    elif c == quote:
                        break

        if brace_balance > 0:
            raise A2uiExpressionError("Unclosed interpolation: missing '}'")

        return scanner.input[start : scanner.pos - 1]

    def parse_expression(self, expr: str, depth: int = 0) -> Any:
        if depth > self.MAX_DEPTH:
            raise A2uiExpressionError("Max recursion depth reached in parse")
        expr = expr.strip()
        if not expr:
            return ""

        scanner = Scanner(expr)
        result = self._parse_expression_internal(scanner, depth)
        if not scanner.is_at_end():
            raise A2uiExpressionError(
                "Unexpected characters at end of expression:"
                f" '{scanner.input[scanner.pos:]}'"
            )
        return result

    def _parse_expression_internal(self, scanner: Scanner, depth: int) -> Any:
        # Both recursive paths pass through here: interpolations nested inside an
        # interpolation, and function-call arguments that are themselves
        # expressions. Checking here counts both.
        if depth > self.MAX_DEPTH:
            raise A2uiExpressionError("Max recursion depth reached in parse")
        scanner.skip_whitespace()
        if scanner.is_at_end():
            return ""

        # 0. Nested Interpolation (Block)
        if scanner.matches("${"):
            scanner.advance(2)
            content = self.extract_interpolation_content(scanner)
            return self.parse_expression(content, depth + 1)

        # 1. Literals
        if scanner.matches_string("'") or scanner.matches_string('"'):
            return self.parse_string_literal(scanner)
        if self.is_number_start(scanner):
            return self.parse_number_literal(scanner)
        if scanner.matches_keyword("true"):
            return True
        if scanner.matches_keyword("false"):
            return False
        if scanner.matches_keyword("null"):
            return ""

        # 2. Identifiers (Function calls or Path starts)
        token = self.scan_path_or_identifier(scanner)
        scanner.skip_whitespace()

        if scanner.peek() == "(":
            return self.parse_function_call(token, scanner, depth)
        else:
            if not token:
                return ""
            return {"path": token}

    def scan_path_or_identifier(self, scanner: Scanner) -> str:
        start = scanner.pos
        while not scanner.is_at_end():
            c = scanner.peek()
            if _is_id_continue(c) or c in ("/", ".", "-"):
                scanner.advance()
            else:
                break
        return scanner.input[start : scanner.pos]

    def parse_function_call(
        self, func_name: str, scanner: Scanner, depth: int
    ) -> dict[str, Any]:
        scanner.match("(")
        scanner.skip_whitespace()

        args = {}

        while not scanner.is_at_end() and scanner.peek() != ")":
            arg_name = self.scan_identifier(scanner)
            scanner.skip_whitespace()
            if not scanner.match(":"):
                raise A2uiExpressionError(
                    f"Expected ':' after argument name '{arg_name}' in function"
                    f" '{func_name}'"
                )
            scanner.skip_whitespace()

            args[arg_name] = self._parse_expression_internal(scanner, depth + 1)

            scanner.skip_whitespace()
            if scanner.peek() == ",":
                scanner.advance()
                scanner.skip_whitespace()

        if not scanner.match(")"):
            raise A2uiExpressionError(
                f"Expected ')' after function arguments for '{func_name}'"
            )

        return {"call": func_name, "args": args, "returnType": "any"}

    def scan_identifier(self, scanner: Scanner) -> str:
        start = scanner.pos
        while not scanner.is_at_end() and _is_id_continue(scanner.peek()):
            scanner.advance()
        return scanner.input[start : scanner.pos]

    def parse_string_literal(self, scanner: Scanner) -> str:
        quote = scanner.advance()
        result = ""
        while not scanner.is_at_end():
            c = scanner.advance()
            if c == "\\":
                next_c = scanner.advance()
                if next_c == "n":
                    result += "\n"
                elif next_c == "t":
                    result += "\t"
                elif next_c == "r":
                    result += "\r"
                else:
                    result += next_c
            elif c == quote:
                break
            else:
                result += c
        return result

    def is_number_start(self, scanner: Scanner) -> bool:
        """Returns whether the scanner is at the start of a number literal.

        A number starts at a digit, at a ``.`` followed by a digit, or at a
        ``-`` or ``+`` sign followed by either of those. The grammar has no
        arithmetic operators, so a sign here can only belong to a literal. A
        ``-`` or ``.`` inside a path such as ``a-1`` or ``a.5`` never reaches
        this check, because the path scanner consumes it as part of the token.
        """
        offset = 1 if scanner.peek() in ("-", "+") else 0
        if self.is_digit(scanner.peek(offset)):
            return True
        return scanner.peek(offset) == "." and self.is_digit(scanner.peek(offset + 1))

    def parse_number_literal(self, scanner: Scanner) -> int | float:
        start = scanner.pos
        if scanner.peek() == "-" or scanner.peek() == "+":
            scanner.advance()
        while not scanner.is_at_end() and (
            self.is_digit(scanner.peek()) or scanner.peek() == "."
        ):
            scanner.advance()
        self.skip_exponent(scanner)
        num_str = scanner.input[start : scanner.pos]
        if not _NUMBER_LITERAL.fullmatch(num_str):
            raise A2uiExpressionError(f"Invalid number literal: '{num_str}'")
        as_float = float(num_str)
        if not math.isfinite(as_float):
            raise A2uiExpressionError(f"Number literal is out of range: '{num_str}'")
        if "." in num_str or "e" in num_str or "E" in num_str:
            return as_float
        sign = -1 if num_str.startswith("-") else 1
        return sign * int(num_str.lstrip("+-").lstrip("0") or "0")

    def skip_exponent(self, scanner: Scanner) -> None:
        """Consumes an exponent suffix (`e` or `E`, an optional sign, then digits).

        A malformed exponent such as `1e` or `1e+` is still consumed, so that
        `parse_number_literal` reports it as an invalid literal instead of leaving
        trailing characters behind.
        """
        if scanner.is_at_end() or scanner.peek() not in ("e", "E"):
            return
        scanner.advance()
        if not scanner.is_at_end() and scanner.peek() in ("+", "-"):
            scanner.advance()
        while not scanner.is_at_end() and self.is_digit(scanner.peek()):
            scanner.advance()

    def is_alnum(self, c: str) -> bool:
        return _is_id_continue(c)

    def is_digit(self, c: str) -> bool:
        return "0" <= c <= "9"
